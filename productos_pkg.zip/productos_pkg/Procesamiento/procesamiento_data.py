import sqlite3
import pandas as pd
import calendar

# Conexion SQL a BD SQLite
sqlite_conn = sqlite3.connect("DB_CSV.db")

def procesamiento():
    #Query para obtener los productos agrupados
    data = sqlite_conn.execute("select product_name,creation_date, CAST(strftime('%m',creation_date)  AS INT) as 'MES', count(product_name) from tbl_csv group by product_name,creation_date order by MES asc").fetchall()
    df = pd.DataFrame(data)
    df.columns =['product_name','creation_date','mes','cantidad']
    
    #Query para obtener la lista meses, correspondientes a los archivos json a generar
    data_m = sqlite_conn.execute("select DISTINCT(CAST(strftime('%m',creation_date)  AS INT)) as 'MES' from tbl_csv order by MES asc").fetchall()
    df_mes = pd.DataFrame(data_m)

    sqlite_conn.close() #cierro conexion
    lista_meses =  [item for sublist in df_mes.values.tolist() for item in sublist] #genero lista aplanada

    #Obs: los Json se generan individuales por mes, gracias al siguiente for
    for n_mes in lista_meses:
       s_mes = calendar.month_name[n_mes]  # obtengo el nombre del mes para luego concatenarlo en el nombre del archivo 
       df[df.mes == n_mes].groupby(['product_name'], as_index=True).apply(lambda x: dict(zip(x.creation_date,x.cantidad))).to_json('ts_productos_' + s_mes + '.json',orient='index')
       # filtro la data por cada mes en df.mes == n_mes, convierto el df en json con metodo to_json(), considerando un diccionario con los key-value, teniendo el producto como index
    print("Proceso finalizado...")
    print("\nArchivos JSON generados en directorio del proyecto")
