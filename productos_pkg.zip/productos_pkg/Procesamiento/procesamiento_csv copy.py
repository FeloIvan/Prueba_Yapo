import time
import sqlite3
import pandas as pd
import glob 
import os
import json

# Conexion SQL a BD SQLite
sqlite_conn = sqlite3.connect("DB_CSV.db")
#cur = sqlite_conn.cursor()
 
#data = sqlite_conn.execute("select product_name,creation_date, count(product_name) from tbl_csv group by product_name,creation_date order by product_name").fetchall()

data = sqlite_conn.execute("select product_name,creation_date, CAST(strftime('%m',creation_date)  AS INT) as 'MES', count(product_name) from tbl_csv group by product_name,creation_date order by MES asc").fetchall()
df = pd.DataFrame(data)
df.columns =['product_name','creation_date','mes','cantidad']

print(type(df)) 
print(df)

df_may = df[df['mes'] == 5]
#print(df_may)
#print(df_may.to_string(index=False))



m = (df_may.groupby(['product_name'], as_index=True)
       .apply(lambda x: dict(zip(x.creation_date,x.cantidad)))
       .to_json(orient='index'))
 
#print(json.dumps(json.loads(j), indent=2, sort_keys=True))
 
m = (df_may.groupby(['product_name'], as_index=True)
       .apply(lambda x: dict(zip(x.creation_date,x.cantidad)))
       .to_json('ts_productos_may.json',orient='index'))

df_june = df[df['mes'] == 6]
#print(df_june)
#print(df_june.to_string(index=False))


j = (df_june.groupby(['product_name'], as_index=True)
       .apply(lambda x: dict(zip(x.creation_date,x.cantidad)))
       .to_json(orient='index'))

 
#print(json.dumps(json.loads(j), indent=2, sort_keys=True))
 

j = (df_june.groupby(['product_name'], as_index=True)
       .apply(lambda x: dict(zip(x.creation_date,x.cantidad)))
       .to_json('ts_productos_june.json',orient='index'))