import sqlite3
import pandas as pd
import glob 
import os

path_bd = 'DB_CSV.db' # archivo BD sqlite
path = '/home/felo/Documentos/Prueba_Yapo/products/*'  # path con * para lectura de todos los directorios, en este caso may/june
all_files = glob.glob(path + "/*.csv")
sqlite_conn = sqlite3.connect("DB_CSV.db")
 
# Obs: para la lectura se eliminó los headers de los csv products00.csv en ambas carpetas
def lee_csv(): 
    df_list = []  #declaro lista para los dataframes
    i = 1
    for archivo in all_files:
        print(f"Reading CSV File {i}/{len(all_files)} : {archivo}")
        pd_csv = pd.read_csv(archivo, sep = ',')
        df_list.append(pd_csv)
        i += 1
    return df_list  

def carga_csv(df_list): 
    i = 1    
    
    #if(os.path.isfile(path_bd)):
        #print("Eliminando Base de Datos...") #Elimino el archivo de la bd para cargar la data desde 0
        #os.remove(path_bd)  
    print("\nIniciando proceso de carga...")
    for dataset in df_list:
        print(f"Cargando DataSet CSV File {i}/{len(df_list)}")
        dataset.columns =['product_name','category_name','pri_pro','price','region','ad_id_pk','plataform_id_pk','seller_name','creation_date','natural','job','promotional','rrss','user_agent','email','transaction','birth_date','seller_email','country','time']
        dataset.to_sql("tbl_csv",sqlite_conn,if_exists="append")  #cada dataset correspondiente a los CSV es cargado en tabla "tbl_csv"
        i += 1        
    sqlite_conn.close()


